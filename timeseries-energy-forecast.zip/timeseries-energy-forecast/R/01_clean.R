library(readr)
library(dplyr)
source("R/cleaning.R")

raw   <- read_csv("data/raw/energy_demand.csv", show_col_types = FALSE)
clean <- clean_energy_series(raw)

cat("Days:        ", nrow(clean), "\n")
cat("Date range:  ", format(min(clean$date)), "to", format(max(clean$date)), "\n")
cat("Missing days:", sum(is.na(clean$demand)), "\n")

saveRDS(clean, "data/clean/energy_tsibble.rds")
