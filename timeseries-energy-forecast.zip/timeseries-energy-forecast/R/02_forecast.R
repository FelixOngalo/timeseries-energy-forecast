library(dplyr)
library(tsibble)
library(fable)
source("R/ts_functions.R")

ts_data <- readRDS("data/clean/energy_tsibble.rds")

decomp <- decompose_series(ts_data)
saveRDS(decomp, "data/clean/decomposition.rds")

split <- split_train_test(ts_data, test_days = 60)
fit   <- fit_forecast_models(split$train)
eval  <- evaluate_forecasts(fit, split$test)

cat("Accuracy on 60-day holdout (sorted best to worst by RMSE):\n")
print(eval$accuracy_tbl)

saveRDS(list(
  ts_data    = ts_data,
  train      = split$train,
  test       = split$test,
  fit        = fit,
  forecasts  = eval$forecasts,
  accuracy   = eval$accuracy_tbl
), "data/clean/forecast_results.rds")
