# Data: this project ships with a SIMULATED daily energy-demand series
# (R/00_simulate_data.R) with known, engineered trend and seasonality --
# that's deliberate, for the same reason earlier projects in this
# portfolio (market-basket-analysis, anomaly-detection-transactions) used
# simulated ground truth: it lets the report CONFIRM the forecasting
# method correctly recovers patterns we know are really there, before
# trusting it on data where the true pattern is unknown.
#
# To use REAL data instead, the EIA (U.S. Energy Information
# Administration) publishes free hourly electricity demand by region, no
# key needed for bulk downloads:
#   https://www.eia.gov/opendata/browser/electricity/rto/region-data
# A simpler alternative is the Kaggle dataset "Hourly Energy Consumption"
# (PJM Interconnection). Either way, save a CSV with at least a
# datetime column and a demand/consumption column to
# data/raw/energy_demand.csv, then skip 00_simulate_data.R and adjust the
# column names at the top of R/01_clean.R to match your file.
message("Using simulated data by default -- run R/00_simulate_data.R. For real data, see the comments in this file.")
