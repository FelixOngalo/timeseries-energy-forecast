# Reusable functions for decomposing and forecasting a daily time series,
# using the "tidyverts" ecosystem (tsibble + fable + feasts). These
# functions are deliberately thin wrappers that NAME each step clearly --
# the real learning value of this project is in reading the comments
# here and in the report, which explain WHY each modeling choice is
# made, not just how to call the function.

library(dplyr)
library(tsibble)
library(fable)
library(feasts)

#' Decompose a tsibble into trend, seasonal, and remainder components
#' using STL (Seasonal-Trend decomposition using Loess). STL is used here
#' rather than classical decomposition because it handles a time series
#' with MULTIPLE seasonal periods at once (this series has both weekly
#' and annual seasonality) and because its trend/seasonal components can
#' each change smoothly over time, rather than being forced constant for
#' the whole series.
#'
#' @param ts_data A tsibble with a `demand` column and a daily index.
#' @return A fabletools "dable" (decomposition table) with trend,
#'   season_week, season_year, and remainder columns.
decompose_series <- function(ts_data) {
  ts_data |>
    model(STL(demand ~ trend(window = 90) + season(period = "week") + season(period = "year"))) |>
    components()
}

#' Split a tsibble into train/test by holding out the last `test_days`
#' days. This is NOT a random split (as you'd use for i.i.d. data like
#' the churn-prediction project) -- for time series, the test set must
#' come strictly AFTER the training period, because a forecasting model
#' is only useful if it can predict the FUTURE from the PAST. A random
#' split would let the model "see" data from after the test period
#' during training, which no real forecast ever gets to do.
#'
#' @param ts_data A tsibble.
#' @param test_days Number of most-recent days to hold out.
#' @return A list: train, test (both tsibbles).
split_train_test <- function(ts_data, test_days = 60) {
  cutoff <- max(ts_data$date) - test_days
  list(
    train = ts_data |> filter(date <= cutoff),
    test  = ts_data |> filter(date > cutoff)
  )
}

#' Fit several forecasting models to the training data, ranging from a
#' naive baseline to models that explicitly use the series' seasonal
#' structure:
#'   - NAIVE: tomorrow = today. The simplest possible forecast, and the
#'     bar every other model needs to clear to be worth its complexity.
#'   - SNAIVE: today = the same weekday last week. A naive forecast that
#'     at least accounts for weekly seasonality, still with no trend.
#'   - ETS: Exponential smoothing with trend and seasonal components
#'     fitted automatically (Error-Trend-Seasonal state-space model).
#'   - ARIMA: Auto-Regressive Integrated Moving Average, fitted via
#'     fable's automatic order selection -- models the series' own
#'     autocorrelation structure (how today relates to recent past
#'     values) after differencing out trend/seasonality.
#'
#' @param train A training tsibble.
#' @return A mable (model table) with one fitted model per column.
fit_forecast_models <- function(train) {
  train |>
    model(
      naive  = NAIVE(demand),
      snaive = SNAIVE(demand ~ lag("week")),
      ets    = ETS(demand),
      arima  = ARIMA(demand)
    )
}

#' Forecast forward and score against the true held-out values. Returns
#' both the raw forecast object (for plotting with prediction intervals)
#' and a tidy accuracy table.
#'
#' @param fit A mable from fit_forecast_models().
#' @param test The held-out tsibble to score against.
#' @return A list: forecasts (fable object), accuracy_tbl (tibble of
#'   RMSE/MAE/MAPE/MASE per model, sorted best-to-worst by RMSE).
evaluate_forecasts <- function(fit, test) {
  fc <- fit |> forecast(h = nrow(test))

  accuracy_tbl <- fc |>
    accuracy(test) |>
    as_tibble() |>
    select(model = .model, RMSE, MAE, MAPE, MASE) |>
    arrange(RMSE)

  list(forecasts = fc, accuracy_tbl = accuracy_tbl)
}
