library(dplyr)
library(tsibble)

# Turn a plain (date, demand) data frame into a TSIBBLE -- a time-series-
# aware tibble from the tidyverts ecosystem (tsibble/fable/feasts). A
# tsibble enforces that its time index is regular and unique, which is
# what lets fable's model functions (NAIVE, ETS, ARIMA) work directly on
# it without any manual date-handling bookkeeping.
clean_energy_series <- function(raw) {
  raw |>
    mutate(date = as.Date(date)) |>
    distinct(date, .keep_all = TRUE) |>
    arrange(date) |>
    as_tsibble(index = date) |>
    fill_gaps()   # makes any missing calendar days explicit (as NA), rather than silently skipped -- a forecasting model needs a REGULAR time index
}
