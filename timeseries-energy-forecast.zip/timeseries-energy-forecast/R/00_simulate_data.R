# Simulate 4 years of DAILY energy demand with realistic, engineered
# components -- each one added deliberately so the report can later
# check whether decomposition and forecasting correctly recover it.
#
# Real energy demand has well-known structure this generator mimics:
#   - a slow upward TREND (grid demand grows with population/electrification)
#   - strong ANNUAL seasonality with TWO peaks: winter (heating) and
#     summer (cooling) -- modeled as the sum of two sine waves, since a
#     single sine wave can only produce one peak and one trough per year
#   - WEEKLY seasonality: lower demand on weekends (less commercial/
#     industrial activity)
#   - random noise on top of all of it

library(dplyr)
library(tibble)

set.seed(42)

n_days <- 365 * 4
dates  <- seq(as.Date("2022-01-01"), by = "day", length.out = n_days)
t      <- seq_len(n_days)

# Trend: demand grows roughly 3% per year off a base of 1000 MWh/day
trend <- 1000 * (1.03 ^ (t / 365))

# Annual seasonality, two peaks (winter + summer): day-of-year as a
# fraction of 365, then two sine terms at different phases so the peaks
# land in Jan/Feb and Jul/Aug respectively.
day_of_year <- as.numeric(format(dates, "%j"))
annual_winter <- 120 * cos(2 * pi * (day_of_year - 15)  / 365)   # peak near day 15 (mid-Jan)
annual_summer <-  90 * cos(2 * pi * (day_of_year - 197) / 365 - pi)  # second peak near day 197 (mid-Jul)
annual <- annual_winter + annual_summer

# Weekly seasonality: Mon-Fri higher, Sat-Sun lower
weekday <- weekdays(dates)
weekly  <- ifelse(weekday %in% c("Saturday", "Sunday"), -80, 20)

noise <- rnorm(n_days, mean = 0, sd = 25)

demand <- trend + annual + weekly + noise

energy_demand <- tibble(
  date   = dates,
  demand = round(pmax(demand, 0), 1)   # demand can't be negative
)

dir.create("data/raw", showWarnings = FALSE, recursive = TRUE)
readr::write_csv(energy_demand, "data/raw/energy_demand.csv")

cat("Simulated", nrow(energy_demand), "days of demand,", 
    format(min(dates), "%Y-%m-%d"), "to", format(max(dates), "%Y-%m-%d"), "\n")
