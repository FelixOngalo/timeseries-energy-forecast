# Forecasting Daily Energy Demand

**Question:** *(fill in)* How accurately can we forecast short-term energy demand, and which model (naive, seasonal-naive, ETS, ARIMA) earns its complexity over the simplest possible baseline?

**Key findings:** *(fill in after running the analysis; which model had the lowest RMSE/MASE on the 60-day holdout, and by how much it beat the naive baseline)*

**Tools:** R, tsibble, fable, feasts (the "tidyverts" time-series ecosystem), STL decomposition, Quarto report

## Reproduce

1. `install.packages(c("tidyverse", "tsibble", "fable", "feasts", "scales"))`
2. Run in order:
   - `R/00_simulate_data.R` generates 4 years of simulated daily demand (or supply your own real CSV — see `R/00_get_data.R`)
   - `R/01_clean.R` turns it into a tsibble (a time-series-aware tibble, with a regular, gap-filled date index)
   - `R/02_forecast.R` decomposes the series, splits train/test, fits all four models, and scores them on the holdout
   - Render `reports/report.qmd` for the full written analysis

## Data

Simulated 4-year daily series with engineered ground truth: ~3%/year trend growth, two annual seasonal peaks (winter heating, summer cooling, modeled as two offset sine waves), and lower weekend demand — all with random noise on top. This lets the report confirm decomposition and forecasting correctly recover patterns we know are really there. Swap in real EIA or Kaggle hourly-demand data any time (see `R/00_get_data.R` for links); the pipeline only needs a `date` + `demand` column.

## Method in brief

1. **STL decomposition** splits the series into trend, weekly seasonal, annual seasonal, and remainder components — chosen over classical decomposition because it natively handles *two* seasonal periods at once.
2. **Train/test split** holds out the most recent 60 days — not a random split, since a forecast must only ever use the past to predict the future.
3. **Four models fit** on the training data: NAIVE (tomorrow = today), SNAIVE (today = same weekday last week), ETS (automatic exponential smoothing), ARIMA (automatic autocorrelation modeling).
4. **Evaluated on the holdout** with RMSE, MAE, MAPE, and MASE — MASE in particular gives a direct, built-in comparison against the naive baseline (MASE < 1 means the model beat naive).

## Key concepts

| Concept | What it means here |
|---|---|
| **tsibble** | A time-series-aware tibble enforcing a regular, unique date index — what lets fable's model functions work without manual date bookkeeping |
| **STL decomposition** | Splits a series into trend + seasonal(s) + remainder, handling multiple seasonal periods and allowing each to change gradually over time |
| **NAIVE / SNAIVE baselines** | The simplest possible forecasts; the bar more sophisticated models must clear to justify their complexity |
| **ETS** | Exponential smoothing with trend/seasonal components, auto-fitted; recent data weighted more than distant data |
| **ARIMA** | Models a series' own autocorrelation after differencing out trend/seasonality, with orders chosen automatically |
| **RMSE / MAE / MAPE / MASE** | Forecast accuracy metrics; MASE directly compares a model's error to the naive baseline's error |
| **Prediction intervals** | A forecast's own stated uncertainty range, not just a point estimate — essential for judging whether a model is over- or under-confident |

## Project structure

```
R/00_get_data.R          real-data source links (optional, alternative to simulation)
R/00_simulate_data.R     generates the simulated demand series with known trend/seasonality
R/cleaning.R              tsibble-conversion function
R/01_clean.R              run cleaning, save the tsibble
R/ts_functions.R          decomposition, train/test split, model fitting, accuracy evaluation
R/02_forecast.R           run the full pipeline, save results
reports/report.qmd        written analysis: decomposition, forecasts, accuracy, residual diagnostics
```

## Limitations

- Simulated data has clean, well-behaved seasonality; real demand also responds to temperature, holidays, and one-off events not modeled here.
- A single 60-day holdout period is evaluated — accuracy can vary a lot depending on which period is held out.
- ETS/ARIMA use fable's automatic specification; a tailored model (e.g. with temperature as an external regressor) could do better.
- Only one forecast horizon (60 days) is evaluated — accuracy typically degrades further out, which this report doesn't test directly.
- *(add your own after running it on your own data)*
